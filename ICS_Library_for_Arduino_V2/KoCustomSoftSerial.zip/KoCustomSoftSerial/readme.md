

# KoCustamSoftSerial
---
## Overview
ArduinoデフォルトのSoftSerialからICSデバイスの115200bpsの通信仕様に合わせたSoftSerialを用意しました 。
A SoftSerial has been made available matched to the specifications for 115200bps communications with an ICS device from Arudino’s default SoftSerial.

## Requirement
Arduino IDE
(Arduino UNO,MEGA,mini)

## Usage
配布フォルダのマニュアルをご覧ください。
For details, refer to the manual in the folder provided.

## Licence
Copyleft 2018 Kondo Kagaku co.,ltd.
[LGPL 3.0](https://www.gnu.org/licenses/lgpl.html)


## Author
近藤科学株式会社
Kondo Kagaku co.,ltd.
5636m_000 , T.Nobuhara
近藤科学ホームページ:(<http://kondo-robot.com/>)
